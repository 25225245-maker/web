// JS導入の最小例：DOMContentLoaded と DOM操作
document.addEventListener("DOMContentLoaded", () => {
  const p = document.createElement("p");
  p.textContent = "JavaScriptが読み込まれました（DOM操作の例）。";
  p.className = "note";
  document.body.appendChild(p);
});